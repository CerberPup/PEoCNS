./gg1.exe -u Cmdenv
